﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;



namespace Liczydelko_v3
{
    public class click
    {
        public Rectangle button, Cursor;
        public int temp;
        public bool click_yes;
        public MouseState mouseState;
        
      
        
            public int t = 0;
        
            public void g_click() //klasa odpowiedzialna za klikanie myszka w przycisk
            {
            
                if ((button.Intersects(Cursor)))
                {
                    if (mouseState.LeftButton == ButtonState.Pressed)
                    {
                        t = temp;
                        click_yes = true;
                    }
                }
            }
        
    }

        
    
}
