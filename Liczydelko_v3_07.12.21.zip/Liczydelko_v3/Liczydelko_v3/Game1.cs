﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;



namespace Liczydelko_v3
{

    public class Game1 : Game
    {
        Texture2D scifi, sekund, ztncz, graj, OPIS,tlo2;
        Rectangle buttonGraj, buttonOpis, buttonSekund, buttonztncz;
        int temp = 0;


        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;


        public Game1()

        {

            _graphics = new GraphicsDeviceManager(this);
            _graphics.PreferredBackBufferWidth = 1280;
            _graphics.PreferredBackBufferHeight = 720;
            _graphics.IsFullScreen = false;
            _graphics.ApplyChanges();
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }
        public MouseState mouseState;
        public Rectangle Cursor;
        private void UpdateCursorPosition()
        {
            /* Pozycja kwaratu podąża za pozycją kursora */
            mouseState = Mouse.GetState();
            Cursor.X = mouseState.X; Cursor.Y = mouseState.Y;
        }


        protected override void Initialize()
        {
            IsMouseVisible = true;
            Window.AllowUserResizing = true;

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice);
            graj = Content.Load<Texture2D>("graj");
            OPIS = Content.Load<Texture2D>("OPIS");
            scifi = Content.Load<Texture2D>("scifi");
            ztncz = Content.Load<Texture2D>("zrobtonaczas");
            sekund = Content.Load<Texture2D>("60sekund");
            tlo2 = Content.Load<Texture2D>("tlo2");
            // TODO: use this.Content to load your game content here
        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            //wyznaczenie polozenia po nowej klatce
            buttonGraj.X = GraphicsDevice.Viewport.Width / 2 - 75 - buttonGraj.Size.X / 3;
            buttonGraj.Y = GraphicsDevice.Viewport.Height / 2 - 100 - buttonGraj.Size.Y / 3;


            buttonOpis.X = GraphicsDevice.Viewport.Width / 2 - 75 - buttonOpis.Size.X / 3;
            buttonOpis.Y = GraphicsDevice.Viewport.Height / 2 - buttonOpis.Size.Y / 3;

            // rozmiar przycisku
            buttonGraj.Height = GraphicsDevice.Viewport.Height / 7;
            buttonGraj.Width = GraphicsDevice.Viewport.Width / 7;

            buttonOpis.Height = GraphicsDevice.Viewport.Height / 8;
            buttonOpis.Width = GraphicsDevice.Viewport.Width / 8;

            buttonSekund.X = buttonGraj.X;
            buttonztncz.X = buttonOpis.X;
            buttonSekund.Y = buttonGraj.Y;
            buttonztncz.Y = buttonOpis.Y;
            buttonSekund.Height = buttonGraj.Height;
            buttonztncz.Height = buttonOpis.Height;
            buttonSekund.Width = buttonGraj.Width * 2;
            buttonztncz.Width = buttonOpis.Width * 2;


            UpdateCursorPosition();
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            click c = new click();
            c.Cursor = Cursor;
            c.mouseState = mouseState;
            click c1 = new click();
            c1.Cursor = Cursor;
            c1.mouseState = mouseState;

            classgraj cg = new classgraj();

            SpriteFont font;
            font = Content.Load<SpriteFont>("File");

            GraphicsDevice.Clear(Color.CornflowerBlue);

            _spriteBatch.Begin();
            cg.Draw(_spriteBatch, gameTime, scifi, _graphics);
           // _spriteBatch.Draw(scifi, new Rectangle(0, 0, _graphics.PreferredBackBufferWidth, _graphics.PreferredBackBufferHeight), Color.White);


            if (temp == 0)
            {
                _spriteBatch.Draw(graj, buttonGraj, Color.White);
                //_spriteBatch.Draw(OPIS, new Vector2((_graphics.PreferredBackBufferWidth / 2 - 75), (_graphics.PreferredBackBufferHeight / 2)), Color.White);
                _spriteBatch.Draw(OPIS, buttonOpis, Color.White);

            }


            c.button = buttonGraj;
            c.temp = 1;
            c.g_click();
            if ((c.click_yes == true || temp == 1) && c.temp == 1) // jesli uzytkownik kliknie w button pokazuje to co nizej + nie wyswietla sie nic z innych warunkow
            {
                temp = 1;
                c.temp = 1;
                //cg.Draw(_spriteBatch, gameTime, tlo2, _graphics);

                 _spriteBatch.Draw(sekund, buttonSekund, Color.White);
                 _spriteBatch.Draw(ztncz, buttonztncz, Color.White);
                
                
                
                // _spriteBatch.DrawString(font, "TEEEEEST " + buttonGraj.Y.ToString(), new Vector2(280, 500), Color.White);
            }

            c1.button = buttonOpis;
            c1.g_click();
            if ((c1.click_yes == true || temp == 2) && c1.temp == 1)
            {
                temp = 2;

                // _spriteBatch.DrawString(font, "testv2 " + buttonOpis.Y.ToString(), new Vector2(240, 500), Color.White);
            }






            _spriteBatch.End();
            base.Draw(gameTime);
        }
    }
}
