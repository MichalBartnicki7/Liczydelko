﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;


namespace Liczydelko_v3
{
    public partial class Game1 : Game
    {
        public static int count;
        public static int endfor = 0;
        public static int x, y, wynik;
        public void UpdateCursorPositionszsekund()
        {


        }


        public void LoadContentszekund()
        {




        }

        public void Updateszsekund()
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            {
                Exit();
            }
            buttonmenu.X = GraphicsDevice.Viewport.Width / 8 * 7 - 135;
            buttonrp.X = GraphicsDevice.Viewport.Width / 8 * 7 - 380;
            buttonmenu.Y = GraphicsDevice.Viewport.Height / 7 * 6 - 90;
            buttonrp.Y = GraphicsDevice.Viewport.Height / 7 * 6 - 90;
            buttonmenu.Height = GraphicsDevice.Viewport.Height / 4 * (3 / 2) + 110;
            buttonrp.Height = GraphicsDevice.Viewport.Height / 4 * (3 / 2) + 110;
            buttonmenu.Width = GraphicsDevice.Viewport.Height / 4 * (5 / 3) + 150;
            buttonrp.Width = GraphicsDevice.Viewport.Height / 4 * (5 / 3) + 150;

            buttonA.X = GraphicsDevice.Viewport.Width / 4 - 150;
            buttonB.X = GraphicsDevice.Viewport.Width / 4 * 3 - 150;
            button.X = GraphicsDevice.Viewport.Width / 4 * 2 - 150;

            buttonA.Y = GraphicsDevice.Viewport.Height / 4 * 2 - 100;
            buttonB.Y = GraphicsDevice.Viewport.Height / 4 * 2 - 100;
            button.Y = GraphicsDevice.Viewport.Height / 4 * 2 - 100;

            buttonA.Height = GraphicsDevice.Viewport.Height / 3;
            buttonB.Height = GraphicsDevice.Viewport.Height / 3;
            button.Height = GraphicsDevice.Viewport.Height / 3;

            buttonA.Width = GraphicsDevice.Viewport.Height / 3;
            buttonB.Width = GraphicsDevice.Viewport.Height / 3;
            button.Width = GraphicsDevice.Viewport.Height / 3;


            UpdateCursorPosition();
            //check1();


        }

        public void Drawszsekund()
        {
            SpriteFont font;
            font = Content.Load<SpriteFont>("File");
            dzialanie d = new dzialanie(count);
            d.rozwiaz();

            click c = new click();
            c.Cursor = Cursor;
            c.mouseState = mouseState;


            _spriteBatch.Begin();
           
            if (endfor == (endfor%2))
            {
                if (count == 57) count = 1; // wychodzi poza tablice, potem musze zmienic
                count++;
                d.count = count;
                x = d.x;
                y = d.y;
                wynik = d.wynik; //zeby dzialania sie nie zmieniały
                

            }

               

            cg.Draw(_spriteBatch, tlo2, _graphics);
            _spriteBatch.Draw(menu, buttonmenu, Color.White);
            _spriteBatch.Draw(rozpocznijponownie, buttonrp, Color.White);
            _spriteBatch.Draw(A, buttonA, Color.White);
            _spriteBatch.Draw(B, buttonB, Color.White);
            _spriteBatch.Draw(C, button, Color.White);
            _spriteBatch.DrawString(font, "Podaj wynik dzialania :  " + x + " + " + y, new Vector2(480, 50), Color.CornflowerBlue);
            _spriteBatch.DrawString(font, "Pozostalo Ci  :  " + 40 + " sekund", new Vector2(90, 525), Color.CornflowerBlue);
            _spriteBatch.DrawString(font, "Poprawne odpowiedzi  :  " + 1, new Vector2(90, 600), Color.CornflowerBlue);
            _spriteBatch.DrawString(font, "Niepooprawne odpowiedzi  :  " + 2, new Vector2(90, 650), Color.CornflowerBlue);
            _spriteBatch.DrawString(font,""+wynik, new Vector2(buttonA.X+110, buttonA.Y+85), Color.CornflowerBlue);
            _spriteBatch.DrawString(font, "" + (wynik+2), new Vector2(buttonB.X+110, buttonB.Y+85), Color.CornflowerBlue);
            _spriteBatch.DrawString(font, "" + (wynik-2), new Vector2(button.X+110, button.Y+85), Color.CornflowerBlue);

            endfor = 2;
            if (c.g1_glick(buttonA) == true) //dobule click bug, do poprawy(zapewnoe bede musial zapisac pozycje kursora)
            {
                d.count++;
                endfor = 1;
            }


            _spriteBatch.End();

        }
    }
}

