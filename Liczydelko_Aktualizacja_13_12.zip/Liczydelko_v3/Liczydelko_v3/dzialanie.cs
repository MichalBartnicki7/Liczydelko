﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Liczydelko_v3
{
    public class dzialanie
    {
        // dzialanie matematyczne zalezne od trudnosci
        Random rnd = new Random();

        public List<int> liczby = new List<int>();
        public List<int> rndliczba = new List<int>();

        public dzialanie(int count)
        {
            this.count = count;
        }

        public int count { get; set; }
        public bool poprawnaodp { get; set; }
        public int x { get; set; }
        public int y { get; set; }
        public int wynik { get; set; }
        public int temp { get; set; }



        public void losowanie()
        {

            for (int i = 1; i < 60; i++)
            {

                liczby.Add(i);
                if (i < 10)
                {
                    rndliczba.Add(rnd.Next(1, 10));
                }
                if (i > 10 & i < 20)
                {
                    rndliczba.Add(rnd.Next(10, 100));
                }

                if (i > 30 & i < 40)
                {
                    rndliczba.Add(rnd.Next(100, 200));
                }
                if (i > 40)
                {
                    rndliczba.Add(rnd.Next(1, 10));
                }

            }
        }
        public void rozwiaz()
        {

            losowanie();
            if (count < 30)
            {
                x = liczby[count] + rnd.Next(1, 4);
                y = rndliczba[count];
                wynik = x + y;
            }
            if (count > 40 & count < 50)
            {
                x = liczby[count-39] + rnd.Next(1, 4);
                y = rndliczba[count];
                wynik = x * y;
                
            }


        }





    }
}
